import React from 'react';

import './style.css';

class App extends React.Component{
    constructor(){
        super();
        this.state={
            value:' Some text here',
            editMode:false,
        }

    }

    changeEdit = () => {
        this.setState({
            editMode:!this.state.editMode,
        })
    }

    upDateValue = () => {
        this.setState({
            editMode:false,
            value:this.refs.upValue.value,
        })
    }

    render(){
        return (
            this.state.editMode ?
            <div>
                <input
                type="text"
                defaultValue={this.state.value}  // ete es chgrenq texty chi pahum
                ref="upValue"   //nayir setstatei mej kpela refin
                />
                <button onClick={this.changeEdit}>X</button>
                <button onClick={this.upDateValue}>✔</button>
            </div>
            :
            <div  onDoubleClick={this.changeEdit}>
                {this.state.value}
            </div>
            

        )
    }

}
export default App;
