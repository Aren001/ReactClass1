export const x1 = {
    backgroundImage: 'url(https://i.pinimg.com/originals/b7/a3/a9/b7a3a96a3f76b2fb1b0c46824cbc433a.jpg)',
    height: '100vh',
    width: '100%',
    position: 'fixed',
    backgroundSize: 'cover'
};
export const x2 = {
    backgroundImage: 'url(https://img4.goodfon.ru/wallpaper/nbig/2/87/leto-trava-babochka-oboi-na-rabochii-stol.jpg)',
    height: '100vh',
    width: '100%',
    position: 'fixed',
    backgroundSize: 'cover',
    
};
export const x3 = {
    backgroundImage: 'url(https://imgur.com/download/yqdtMRi)',
    height: '100vh',
    width: '100%',
    position: 'fixed',
    backgroundSize: 'cover',
    
};
export const x4 = {
    backgroundImage: 'url(https://i.pinimg.com/originals/c4/ca/53/c4ca53106606cd8f91b97d502c935eb7.jpg)',
    height: '100vh',
    width: '100%',
    position: 'fixed',
    backgroundSize: 'cover',
    
};