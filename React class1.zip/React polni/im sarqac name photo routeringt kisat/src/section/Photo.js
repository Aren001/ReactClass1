import React from 'react';

import {API_URL} from "../config";



import './Photo.css'





class Photo extends  React.Component {
    constructor() {
        super();
        this.state = {

            arr: [],
            error: null,
            res:2,
          };
          this.handleChangeSelect = this.handleChangeSelect.bind(this);
        
    }

    fetchCurrencies(){
        const {res}=this.state;
        fetch(`${API_URL}/?results=${res}`)
        .then(resp => {
            return resp.json();
        })
        .then(data => {
            console.log(data);
            this.setState({
                arr:data.results,
            })
        })
        .catch((err)=>{
            console.log(err, 'bhjwbvhjfbvhjkbfv')
        })
    }

    componentDidMount(){
       this.fetchCurrencies();
    }

    handleChangeSelect (e){
        this.setState({
            res:e.target.value,
        },() => this.fetchCurrencies())
    }





render(){
    const {arr , res}=this.state;

    return (
        <div className="div8">

            <select style={{backgroundColor:"white",color:"grey",margin:"25px"}} value={res} onChange={this.handleChangeSelect}>
                <option vlaue="2">2</option>
                <option vlaue="5">5</option>
                <option vlaue="7">7</option>
                <option vlaue="10">10</option>
            </select>

        <div className="div22">
            {arr.map((e,index) => {
           return (<div key={index}>
            <img  src={e.picture.thumbnail} className="img8" />
           <h2  className="h22">{e.name.first}</h2>
           
            </div>
           )
            })}
</div>
           
           
        </div>
        )
    }
}
export default Photo;