import React from 'react';

const Select = ({handlChangeSelect , perPage}) => {
    return (
        <div>
            <select value={perPage} onChange={handlChangeSelect}>
                <option value="10" >10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="75">75</option>
            </select>
        </div>
    )
}
export default Select;