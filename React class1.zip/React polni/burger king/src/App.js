import React from 'react';

import './App.css';

class App extends React.Component {
    constructor() {
        super();
        this.state={
            val:'',
            tomato:false,
            meat:false,
            cheese:false,
            bacon:false,
            salad:false,
            checked:false,
        }
        this.buttom=this.buttom.bind(this);
        this.check=this.check.bind(this);
        this.handle=this.handle.bind(this);

    }

    handle(e){
        if(this.state.checked==false)
        {
            this.setState({
                val:'',
            })
        }else{
        this.setState({
            val:e.target.value,
        })
    }

    }

    check(e){
        this.setState({
            checked:e.target.checked,
        })
    }




    buttom(){
        const {val , tomato , meat , cheese , bacon ,salad , checked}=this.state;
        
        if(checked==true && val==2){
            
            
            
            
        }
    

    }







render(){
    const {val , tomato , meat , cheese , bacon ,salad , checked}=this.state;
    return (
        <div className="divG">
            <h1 style={{margin:'0 600px' , position:'absolute'}}>Burger King</h1>
            <div className="section">
            <div>
                <img className="img1" src="./burgerProduct/tomato.png" />
                <div >
                    <label className="div1">
                        <input  className="input1" type="checkbox" checked={checked}  onChange={this.check}  />
                       <h3>Tomato</h3>
                       <input type="number" placeholder="quantity" value={val} onChange={this.handle} />
                    </label>
                </div>
                
            </div>
            <div>
                <img className="img1" src="./burgerProduct/steak.png" />
                <div >
                    <label className="div1">
                        <input className="input1" type="checkbox"  />
                       <h3>Meat</h3>
                       <input type="number" placeholder="quantity" value={val} onChange={this.handle} />
                    </label>
                </div>
                
            </div>
            <div>
                <img className="img1" src="./burgerProduct/cheese.png" />
                <div >
                    <label className="div1">
                        <input className="input1" type="checkbox"  />
                       <h3>Cheese</h3>
                       <input type="number" placeholder="quantity" value={val} onChange={this.handle} />
                    </label>
                </div>
                
            </div>
            <div>
                <img className="img1" src="./burgerProduct/bacon.png" />
                <div >
                    <label className="div1">
                        <input className="input1" type="checkbox"  />
                       <h3>Bacon</h3>
                       <input type="number" placeholder="quantity"  value={val} onChange={this.handle}/>
                    </label>
                </div>
                
            </div>
            <div>
                <img className="img1" src="./burgerProduct/salad.png" />
                <div >
                    <label className="div1">
                        <input className="input1" type="checkbox"  />
                       <h3>Salad</h3>
                       <input type="number" placeholder="quantity" value={val} onChange={this.handle} />
                    </label>
                </div>
                
            </div>
            <button onClick={this.buttom} className="but1">Preaparing</button>
            </div>
            <div className="section ">
                
                <div     className="sec2">
            <div className="bread-top"></div>
                <span >
                {tomato ? <div className="tomato"></div> : null}
                </span>
            <div className="bread-bottom"></div>
            </div>
         
            </div>
        </div>
    )
}
}
export default App;