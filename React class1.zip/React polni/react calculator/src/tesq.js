import React from 'react';
import './main.css';

const Tesq = ({count ,  changeValue ,Reset ,  Calculate , subscribess}) => {
    

    return (
    <div className='container'>
    <div className='row'>
      <input value={count}/>
    </div>
<div className='row'>
  <button onClick={()=> changeValue(1)}>1</button>
  <button onClick={()=> changeValue(2)}>2</button>
  <button onClick={()=> changeValue(3)}>3</button>
  <button onClick={()=> changeValue('+')}>+</button>
</div>
<div className='row'>
  <button onClick={()=> changeValue(4)}>4</button>
  <button onClick={()=> changeValue(5)}>5</button>
  <button onClick={()=> changeValue(6)}>6</button>
  <button onClick={()=> changeValue('-')}>-</button>
</div>
<div className='row'>
  <button onClick={()=> changeValue(7)}>7</button>
  <button onClick={()=> changeValue(8)}>8</button>
  <button onClick={()=> changeValue(9)}>9</button>
  <button onClick={()=> changeValue('*')}>*</button>
</div>
<div className='row'>
  <button onClick={()=> changeValue(0)}>0</button>
  <button onClick={()=> Reset()}>C</button>
  <button onClick={()=> changeValue('.')}>.</button>
  <button onClick={()=> changeValue('/')}>/</button>
</div>
<div className='row'>
  <button className='calculate' onClick={()=>Calculate()}>=</button>
  <button onClick={() => subscribess()}>CE</button>
</div>

    </div> )
} 

export default Tesq;



