import React from 'react';

import Tesq from './tesq';

class App extends React.Component {
  constructor(){
    super();

  this.state={
    count:'0',
    butt:true,
   
  }
  this.changeValue=this.changeValue.bind(this);
  this.Reset=this.Reset.bind(this);
  this.subscribess=this.subscribess.bind(this);
  this.Calculate=this.Calculate.bind(this);
  this.but=this.but.bind(this);
}

but(){
  
  this.setState({
    butt:!this.state.butt,
  })
}

  Reset(){
    this.setState({
      count:'0'
    })
    
  }

  subscribess() {
    const {count}=this.state;
    this.setState({
      count:count.substring(0,count.length-1)
    })
  }

 

  Calculate(){
    const {count}=this.state; 
   
    try {
      this.setState({
          // eslint-disable-next-line
          count: (eval(count) )+""   // vor + heto CE ashxati 
      })
  } catch (e) {
      this.setState({
          count: "EROR"
      }) 
    }
  
    
    
  }

  changeValue(digit){
    const {count}=this.state;
    //o-i popoxutyan mommentna
this.setState({
  count:count==='0' || count=='EROR' ?String(digit):count+digit
})
  }

render(){
  const {butt}=this.state;
    return (
      
     <div>
       <button onClick={() => this.but()}>Change</button>
      
     {butt ? null : <Tesq changeValue={this.changeValue} Reset={this.Reset}   Calculate={this. Calculate}  subscribess={this.subscribess} count={this.state.count} />  }
     

   
    </div>
  )
}
}

export default App;
