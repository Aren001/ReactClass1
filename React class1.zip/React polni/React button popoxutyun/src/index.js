import React from 'react';

import ReactDOM from 'react-dom';

import  LoginControl from './components/Buttonpopoxutyun'






const App = () => {
    return(
        <div>
            <LoginControl/>
        </div>
    )
}

ReactDOM.render(
    <App/>,
    document.getElementById("root")
)


  

  