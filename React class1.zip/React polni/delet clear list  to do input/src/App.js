import React from 'react';

import  Todoinput from './components/Todoinput';

import TodoList from'./components/TodoList';

import uuid from 'uuid';


class App extends React.Component{
    constructor(){
        super();
        this.state={
            items:[],
            id:uuid(),
            item:'',
            // editItem:false,
        }
        // this.handleDelete=this.handleDelete.bind(this);
    }



    handleSubmit=(e) => {
        e.preventDefault();


        const newItem={
            id:this.state.id,
            title:this.state.item,
        }

        const updateItems=[... this.state.items,newItem];
       // console.log(newItem);
       this.setState({
        items:updateItems,
        item:"",
        id:uuid(),
        // editItem:false,

    })
    };



    handleChange =(e) => {
        this.setState({
            item:e.target.value,
        })
    }



    clearList=() => {
        this.setState({
            items:[],
        })
    }


    handleDelete=(id) => {
        const titleDel=this.state.items.filter(item => item.id !== id);
        this.setState({
            items:titleDel,
        })
    }

    handleEdit= id => {

        const titleDel=this.state.items.filter(item => item.id !== id);
        const select=this.state.items.find(item => item.id===id);
        console.log(select);

        this.setState({
            items:titleDel,
            item:select.title,
            editItem:true,
            id:id,
        })


    }


    render () {
        const { items , id , item , editItem}=this.state;
        return (
            <div className="container">
               <div className="row">
                   <div className="col-10 mx-auto col-md-8 mt-4">
                       <h3 className="text-capitalize text-center">todo input</h3>
                   <Todoinput item={item} 
                    handleChange={this.handleChange} 
                     handleSubmit={this.handleSubmit}
                     editItem={editItem}
                     />
                <TodoList
                 items={items} 
                  clearList={this.clearList} 
                   handleDelete={this.handleDelete}
                   handleEdit={this.handleEdit}
                   
                   />
                   </div>
               </div>
            </div>
        )
    }
}


export default App;
