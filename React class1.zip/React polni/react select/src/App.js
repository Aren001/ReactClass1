import React from "react";
import "./styles.css";

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      currentPage: 1,
      todosPerPage: 4,
      data: [
        { id: 1, text: "Hello World1" },
        { id: 2, text: "Hello World2" },
        { id: 3, text: "Hello World3" },
        { id: 4, text: "Hello World4" },
        { id: 5, text: "Hello World5" },
        { id: 6, text: "Hello World6" },
        { id: 7, text: "Hello World7" },
        { id: 8, text: "Hello World8" },
        { id: 9, text: "Hello World9" },
        { id: 10, text: "Hello World10" },
        { id: 11, text: "Hello World11" }
      ]
    };
  }

  handleClick = event => {
    this.setState({
      currentPage: Number(event.target.id)
    });
  };

  renderPageNumbers = () => {
    const { todosPerPage, data } = this.state;
    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(data.length / todosPerPage); i++) {
      pageNumbers.push(i);
    }

    return pageNumbers.map(number => {
      return (
        <button key={number} id={number} onClick={this.handleClick}>
          {number}
        </button>
      );
    });
  };

  renderDataList = () => {
    const { data, currentPage, todosPerPage } = this.state;

    const indexOfLastTodo = currentPage * todosPerPage;
    const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
    const currentTodos = data.slice(indexOfFirstTodo, indexOfLastTodo);

    return currentTodos.map(todo => {
      return <li key={todo.id}>{todo.text}</li>;
    });
  };

  handleChangePageSize = e => {
    this.setState({
      todosPerPage: e.target.value
    });
    console.log(e.target.value);
  };

  render() {
    return (
      <div className="Table-container">
        <div>
          <ul>{this.renderDataList()}</ul>

          {this.renderPageNumbers()}
        </div>

        <select onChange={this.handleChangePageSize}>
          <option>Page Size</option>
          <option value={2}>2</option>
          <option value={4}>4</option>
          <option value={8}>8</option>
          <option value={12}>12</option>
        </select>
      </div>
    );
  }
}
export default App;
