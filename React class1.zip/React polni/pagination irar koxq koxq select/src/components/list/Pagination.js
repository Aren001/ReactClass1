import React from 'react';
import './Pagination.css';

const Pagination = ({page , totalPages , handlePeginationClick}) => {
    const arrays=[];
    for( page=1;page<=totalPages;page++){
        arrays.push(page);
    } 
    return (
        <div  style={{display:'flex' , margin:'50px 600px'}}>
            {arrays.map((number ,index) => {
                return <div key={index}  style={{display:'flex', marginLeft:'10px'}}>
                    <button onClick={() =>  handlePeginationClick(number)}>{number}</button>
                </div>
            })}
        </div>
    )
};
export default Pagination;