import React from 'react';

 class Teg extends React.Component{
     constructor(){
         super();
         this.state={
             imput:'hello',
             data:new Date(),
             count:0
         }
     }

    
     tick(){
        
         this.setState({
             data:new Date(),
             count:this.state.count+1,
         })
     }

     componentDidMount() {
         
       //intervaly comentic hanumes jamnaa artahaytum
        // this.inter= setInterval(()=> {this.tick()},1000)
        // clearInterval(this.inter)                           
     }
increment = () => {
    this.setState({
        count:this.state.count+1,
    })
}
decrement = () => {
    this.setState({
        count:this.state.count-1,
    })
}


    



     render(){
         return (
         <div>
             <h1>{this.state.data.toLocaleTimeString()}</h1>
         <h1>{this.state.count}</h1>
         <h1><button onClick={this.increment}>{'increment'}</button></h1>
         <h1><button onClick={this.decrement}>{'decrement'}</button></h1>
         
         </div>
         )
     }
 }
 export default Teg;