import React from 'react';

import ReactDOM from 'react-dom';

import Coffe from './coffe';

import './style.css';


const App = () => {
    return (
        <div>
            <Coffe/>
        </div>
    )
}

ReactDOM.render(<App/>,document.getElementById('root'));
