export const API_URL = 'https://api.openweathermap.org/data/2.5/weather?q=';
export const API_KEY = 'fd48bdf8a8b87b3c140f17625f4e2d57';
