import React from 'react';

import {API_URL} from '../../config';

import Loading from './Loading';


import { withRouter } from 'react-router-dom';

import './Search.css';

class Search extends React.Component {
  constructor() {
    super();

    this.state = {
      searchResults: [],
      searchQuery: '',
      loading: false,
    }
    this.handleChange=this.handleChange.bind(this);
    this.renderSearchResult=this.renderSearchResult.bind(this);
    this.hendelRedirect=this.hendelRedirect.bind(this);
  }






  handleChange(e) {
    const searchQuery=e.target.value;
    // console.log(searchQuery);
    this.setState({searchQuery}) //qani vor keyery nuynna senc karanq grenq<-  
    this.setState({
      loading:true
    }) 
    fetch(`${API_URL}/autocomplete?searchQuery=${searchQuery}`) //esi beckendi temana    //amen tar greluc searcha anum
    .then(resp => resp.json())
    .then(result => {
      // console.log(result);
      this.setState({
        searchResults:result,
        loading:false,
      })
    })
  }




  hendelRedirect(id) {
    this.props.history.push(`/currency/${id}`)  //with routerovenq kazmakerpum
    this.setState({
      searchQuery:'',
      searchResults:[],
    })
  }







renderSearchResult(){
  const {searchResults , searchQuery , loading}=this.state;

  if(!searchQuery){
    return '';
  }
  if(searchResults.length>0){
    return (
      <div className="Search-result-container">
        {
          searchResults.map(result => {
            return (
              <div className="Search-result"
               key={result.id}
               onClick={() => this.hendelRedirect(result.id)}
               >
                {result.name} ({result.symbol})
              </div>
            )
          })
        }
      </div>
    )
  }
  if(!loading) {
    return (
      <div className="Search-result-container">
        <div className="Search-no-result"> NO RESULT</div>
      </div>
    )
  }
}





  render(){
    
    const {searchResults , searchQuery , loading}=this.state;
   console.log(this.state)
      return (
        <div className='Search'>
        <div>
          <span className="Search-icon" />
          <input 
            
            type="text"
            className="Search-input"
            placeholder="Currency name"
           onChange={this.handleChange}
           value={searchQuery}
          />

        {
          loading && (
            <div className="Search-loading">
                <Loading  //Loadingum proptyps unenq arac
                 />
            </div>
          )
        }
         
            
        </div>
        {this.renderSearchResult()}
        
      </div>
      )
  }

  
}

export default withRouter(Search);








