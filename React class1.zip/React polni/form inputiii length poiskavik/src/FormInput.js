import React from 'react';
import obj from './object';

export default class FormInput extends React.Component {
    constructor(){
        super();
        this.state={
            fullName:'',
            obj1:[],
        }
    }
    buttons=() => {

    }

    handleSubmit=(event) => {
        const {fullName}=this.state;
        if(fullName==='')
        alert('enter Name')
       
        event.preventDefault();
    }
    handleInputChange = (e) => {
        
        
        this.setState({
        fullName:e.target.value,
            
        })
    }
   componentDidMount(){
       this.setState({
           obj1:obj,
       })
       console.log(obj);
   }
    render() {
        const {obj1 , fullName}=this.state;
        return (
            <div>
                <h1>Forms and inputs</h1>
        <h1>FullName {this.state.fullName}</h1>
       
    <h1>{this.state.fullName.length}</h1>
                <form  onSubmit={this.handleSubmit}>
                    <p><input onChange={this.handleInputChange}  value={fullName} type="text" placeholder="Your Name" name="fullName"  /></p>
                    <p><button  onClick={this.buttons} >Send Message</button></p>
                </form>
                {obj1.map(e => {
                    
                    if(e.name===fullName)
                  return (
                    <div style={{backgroundColor:'red'}} key={e.age}> 
                        <h1>{e.age}</h1>
                        <h1>{e.first}</h1>
                    </div>
                )
               
                

        })}
            </div>
        )
    }
}

