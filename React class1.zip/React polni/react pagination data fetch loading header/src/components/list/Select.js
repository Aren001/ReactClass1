import React from "react";

class Select extends React.Component {
    constructor(props){
        super(props)
    }
    render(){
        return(<div>
                <select id="select" onChange={this.props.change}>
                    <option value="5">5</option>
                    <option value="15">15</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                </select>                
            </div>
        )
    }
}
export default Select