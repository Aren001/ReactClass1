import React from "react";
import { API_URL } from "../../config";
import Loading from ".././common/Loading";
import { renderChangePercent } from '../../helpers';
import Pagination from './Pagination';
import Select from "./Select"
import "./Table.css";

class List extends React.Component {
  constructor() {
    super();
    this.state = {
      loading: false,
      currencies: [],
      error: null,
      perPage: 50
    };
  }
  componentDidMount() {
    const { perPage } = this.state;
    this.setState({
      loading: true
    });
    fetch(`${API_URL}/cryptocurrencies/?page=1&perPage=${perPage}`)
      .then(resp => {
        return resp.json().then(data => {
          if(resp.ok) {
              return data
          }else {
            return Promise.reject(data)
          }
        })
      })
      .then(data => {
        this.setState({
          loading: false,
          currencies: data.currencies
        })
      })
      .catch((err)=>{
          console.log(err, 'bhjwbvhjfbvhjkbfv')
      })
  }
  render() {
    const { loading, currencies, error } = this.state;
    if (loading) {
      return (
        <div className="loading-container">
          <Loading />
        </div>
      );
    }
    return (
      <div className="Table-container">
        <Select change={this.change}/>
        <table className="Table">
          <thead className="Table-head">
            <tr>
              <th>Cryptocurrency</th>
              <th>Price</th>
              <th>Market Cap</th>
              <th>24H Change</th>
            </tr>
          </thead>
          <tbody className="Table-body">
            {
              currencies.map((currency) => {
                return (
                  <tr key={currency.id}>
                      <td>
                        <span className="Table-rank">{currency.rank}</span>
                        {currency.name}
                      </td>
                      <td>
                        <span className="Table-dollar">$</span>
                        {currency.price}
                      </td>
                      <td>
                        <span className="Table-dollar">$</span>
                        {currency.marketCap}
                      </td>
                      <td>
                          {renderChangePercent(currency.percentChange24h)}
                      </td>
                  </tr>
                )
              })    
            }
          </tbody>
        </table>
        <Pagination />
      </div>
    );
  }
}
export default List;