import React from 'react';

export const renderChangePercent = changePercent => {
    if(changePercent>0){
        return(
            <spun className="percent-raised">
                {changePercent} % &uarr;
            </spun>
        )
    }
    else if(changePercent<0){
        return(
            <spun className="percent-fallen">
                {changePercent} % &darr;
            </spun>
        )
    }
    else{
        return(
            <spun>
                {changePercent} % 
            </spun>
        ) 
    }
}