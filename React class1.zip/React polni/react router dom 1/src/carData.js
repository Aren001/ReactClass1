export const carData = [
    { name: 'BMW', link: '/bmw', model: 'X6m' },
    { name: 'Opel', link: '/opel', model: 'Zafira' },
    { name: 'Tesla', link: '/tesla', model: 'modelX' },
];

// <h2>{props.match.params.id.toUpperCase()}</h2>