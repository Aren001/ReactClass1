import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class SignInForm extends Component {
    constructor () {
        super();

        this.state={
            email:'',
            password:'',
            dav:false,
        }

        this.handleChange=this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      
    }

    handleChange (e) {
        let target = e.target;
        let value = target.type === 'checkbox' ? target.checked : target.value;
        let name = target.name;

        this.setState({
          [name]: value  //emaily poxuma name-n stringa ["ghgjh"]='tretuyuy'   poxuma emaili name-n
        });
    }
    handleSubmit (e) {
        e.preventDefault();
        console.log('Email .......  Passsword');
        console.log('sarqac objectna',this.state);
        this.setState({
            dav:true,
          })
       
    }

   
    

    render() {
        
        if(this.state.dav)
        {
            return (
                <div>
                    <h1>{this.state.email}</h1>
            <h1>{this.state.password}</h1>
                </div>
            )
        }

        return (
        <div className="FormCenter">

      

            <form className="FormFields" onSubmit={this.handleSubmit} >

            <div className="FormField">

                <label className="FormField__Label" htmlFor="email">E-Mail Address</label>

                <input type="email" id="email" className="FormField__Input" placeholder="Enter your email" name="email" 
                value={this.state.email}  onChange={this.handleChange}  required	 />

              </div>

              <div className="FormField">

                <label className="FormField__Label" htmlFor="password">Password</label>

                <input type="password" id="password" className="FormField__Input" placeholder="Enter your password" name="password" 
                value={this.state.password}  onChange={this.handleChange} required	 />

              </div>

              <div className="FormField">

                  <button className="FormField__Button mr-20" onClick={this.foo}>Sign In</button> <Link to="/" className="FormField__Link">Create an account</Link>

              </div>

            </form>

        

          </div>
        );
    }
}

export default SignInForm;
