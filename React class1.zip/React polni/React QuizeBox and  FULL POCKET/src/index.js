import React , {Component} from 'react';

import ReactDOM from 'react-dom';

import quize from './quize';

import QuestionBox  from './components/QuestionBox';

import Result from './components/result';

import "./assets/style.css";

class Quize extends Component {
    state={
        quest:[],
        score:0,
        response:0,
    }
    

    getquestion=() => {
        quize()
        .then(question => {
            this.setState({
                quest:question,
            })
        })

    }

    computeAnswer=(answer , correctAns) => {
        if(answer===correctAns) 
        {
            this.setState({
                score:this.state.score + 1
            })
        }
        this.setState({
            response:this.state.response < 5 ? this.state.response + 1 : 5 
        })
    }

    playAgain =() => {
        this.getquestion();
        this.setState({
            score:0,
            response:0
        })
    }

    componentDidMount(){
        this.getquestion();
    }

    render(){
        return (
            <div className="container">
                <div className="title">quizebee</div>
        {this.state.quest.length>0 && this.state.response < 5 && this.state.quest.map(({question , answers , correct , questionId})=> 
        <QuestionBox question={question}
         options={answers}
          key={questionId}
          selected={answer => this.computeAnswer(answer , correct)}
           />)}

        {this.state.response === 5 ? <Result score={this.state.score} playAgain={this.playAgain} /> : null }
            </div>
        )
    }
}







ReactDOM.render(<Quize />,document.getElementById('root'));


